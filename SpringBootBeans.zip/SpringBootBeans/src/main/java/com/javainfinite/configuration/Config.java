package com.javainfinite.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import com.javainfinite.beans.Employee;
import com.javainfinite.beans.Student;

@Configuration
public class Config {
	
	@Bean
	public Employee employee() {
		return new Employee();
	}
	
	@Bean
	@Lazy(value = true)
	public Student student() {
		return new Student();
	}

}
